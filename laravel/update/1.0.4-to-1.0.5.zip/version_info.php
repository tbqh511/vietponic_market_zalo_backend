<?php
return array(
    'current_version'=>'1.0.4',
    'update_version'=>'1.0.5'
);
